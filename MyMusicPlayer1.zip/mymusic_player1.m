%% My Music Player using Matlab
% You can Listen to your favorite music while working with your matlab. It doen't require any music player pre-installed.
% You all need to add your favorite tracks to this folder. Run the program to select your fovorite song. 
% If you want :
% to pause use pause(p)
% to resume -- resume(p)
% to stop -- stop(p)

filename = uigetfile('*.*');
[y,Fs] = audioread(filename);
player = audioplayer(y,Fs);
p=player;
play(p);
